<?php
$conn = mysqli_connect("localhost", "root", "99" , "note_android");
